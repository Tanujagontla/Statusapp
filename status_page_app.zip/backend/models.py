from sqlalchemy import Column, Integer, String, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from database import Base

class Service(Base):
    __tablename__ = "services"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    status = Column(String, default="Operational")  # Operational, Degraded, Outage
    incidents = relationship("Incident", back_populates="service")

class Incident(Base):
    __tablename__ = "incidents"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(String)
    resolved = Column(Boolean, default=False)
    service_id = Column(Integer, ForeignKey("services.id"))
    service = relationship("Service", back_populates="incidents")
    