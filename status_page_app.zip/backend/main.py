from fastapi import FastAPI, Depends, WebSocket
from sqlalchemy.orm import Session
from database import SessionLocal, engine
import models

app = FastAPI()

models.Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/services/")
def create_service(name: str, db: Session = Depends(get_db)):
    service = models.Service(name=name)
    db.add(service)
    db.commit()
    db.refresh(service)
    return service

@app.get("/services/")
def get_services(db: Session = Depends(get_db)):
    return db.query(models.Service).all()

# WebSocket for real-time status updates
active_connections = []

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            for connection in active_connections:
                await connection.send_text(f"Status Update: {data}")
    except Exception as e:
        active_connections.remove(websocket)
    