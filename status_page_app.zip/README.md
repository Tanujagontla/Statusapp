# Status Page Application

## Overview
This project is a simplified **status page application** inspired by StatusPage, Cachet, and BetterStack.
It allows administrators to manage services, update their statuses, and provide a **public-facing status page**.

## Features
- **User Authentication** (via Clerk/Auth0)
- **Team & Organization Management** (Multi-Tenant)
- **Service Management** (CRUD Operations)
- **Incident & Maintenance Handling**
- **Real-time Status Updates** (WebSockets)
- **Public Status Page**
- **Deployed on Vercel & Heroku**

## Tech Stack
- **Frontend:** React.js with Shadcn UI
- **Backend:** FastAPI (Python) + PostgreSQL
- **WebSockets for Live Updates**
- **Deployment:** Vercel (Frontend), Heroku (Backend)

## Setup Instructions
### Backend (FastAPI)
1. Install dependencies: `pip install fastapi uvicorn sqlalchemy psycopg2`
2. Run the server: `uvicorn main:app --reload`

### Frontend (React.js)
1. Install dependencies: `npm install`
2. Start the frontend: `npm start`

## Deployment
- **Frontend:** `vercel`
- **Backend:** `heroku push main`

## Demo Login Credentials
- **Email:** testuser@example.com
- **Password:** demo123

## Loom Walkthrough
Watch the video: [Loom Demo Link]
